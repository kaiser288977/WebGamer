function TutorialModel(){
	base(this,MyModel,[]);
}
TutorialModel.prototype.construct=function(){
};
/*
TutorialModel.prototype.getImages=function(){
	var list = [
		{name:"bigmap",path:LMvc.IMG_PATH+"map/bigmap.png"},
		{name:"face-1",path:LMvc.IMG_PATH+"face/face-1.png"},
		{name:"face-2",path:LMvc.IMG_PATH+"face/face-2.png"},
		{name:"face-3",path:LMvc.IMG_PATH+"face/face-3.png"},
		{name:"face-4",path:LMvc.IMG_PATH+"face/face-4.png"}
	];
	return list;
};*/