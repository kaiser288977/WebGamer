function GameView(){
	base(this,LView,[]);
}
GameView.prototype.construct=function(){
};