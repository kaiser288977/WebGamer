function TutorialView(){
	base(this,LView,[]);
}
TutorialView.prototype.construct=function(){
};