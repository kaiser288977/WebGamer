function MyController(){
	base(this,LController,[]);
}
MyController.prototype.construct=function(){
};