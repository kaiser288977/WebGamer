//地图图片数组
var map;
//地图地形数组
var mapdata ;